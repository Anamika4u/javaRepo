package com.exception;

public class InvalidPersonalIdException extends Exception {
	public InvalidPersonalIdException(String s) {
		return;
	}
	
	// Write a public single argument constructor ( with String message as an argument ) and set the message to the super class constructor

}
